package ktm.ktm;

import java.security.PublicKey;

public class NhanVienQuanLy extends NhanVien {
	private String chuyenMon;
	private double phuCapChucVu;
	
	public NhanVienQuanLy(String maNv, String tenNv, String trinhDo, double luongCoBan, String chuyenMon, double phuCapChucVu ) {
		super(maNv, tenNv, trinhDo, luongCoBan);
		this.chuyenMon = chuyenMon;
		this.phuCapChucVu = phuCapChucVu;
	}

	@Override
	public double tinhLuong() {
		// TODO Auto-generated method stub
		return getLuongCoBan() + getPhuCapChucVu();
	}

	public String getChuyenMon() {
		return chuyenMon;
	}

	public void setChuyenMon(String chuyenMon) {
		this.chuyenMon = chuyenMon;
	}

	public double getPhuCapChucVu() {
		return phuCapChucVu;
	}

	public void setPhuCapChucVu(double phuCapChucVu) {
		this.phuCapChucVu = phuCapChucVu;
	}
	

}
