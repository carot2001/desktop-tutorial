package ktm.ktm;

import java.util.Scanner;

public class Entry {
	public static void main(String[] args) {
		HocVien hocVien = new HocVien();
		
		//Truyen tham so
//		NhanVienQuanLy nvql = new NhanVienQuanLy("NV01", "LMH", "Dai Hoc", 1000, "Hoa Hoc", 100);
//		System.out.println("Luong cua nhan vien quan ly la: " + nvql.tinhLuong());
//		NhanVienNghienCuu nvnc = new NhanVienNghienCuu("NV02", "Huynh Khai Van", "Dai Hoc", 1500, "CNTT", 200);
//		System.out.println("Luong cua nhan vien nghien cuu la: " + nvnc.tinhLuong());
//		NhanVienPhucVu nvpv = new NhanVienPhucVu("NV03", "Tu Nguyen Minh Dang", "THPT", 700);
//		System.out.println("Luong cua nhan vien phuc vu la: " + nvpv.tinhLuong());
		
		
		//Truyen tham so chu dong.
//		qlnv.showElement();
//		
//		qlnv.Function();
//		qlnv.Calculate();
		
		
			Scanner sc = new Scanner(System.in);
			boolean continueProgram = true;
			while(continueProgram) {
				
			//Function
			System.out.println("MENU CHỨC NĂNG.");
			System.out.println("1. Nhập thông tin nhân viên. ");
			System.out.println("2. Hiển thị thông tin nhân viên. ");
			System.out.println("3. Tính lương của từng nhân viên. ");
			System.out.println("4. Hiện tổng lương của tất cả nhân viên. ");
			
			//Choose Function
			System.out.print("Chọn chức năng: ");
			int chooseFunc = sc.nextInt();
			//Switch case MenuFunc.
			switch (chooseFunc) {
			case 1:
				hocVien.Function();
				break;
			case 2:
				hocVien.showElement();
				break;
			case 3:
				hocVien.Calculate();
				break;
			case 4:
				System.out.println("Tổng lương của tất cả nhân viên trong học viện: " + hocVien.TotalSalary());
				break;
			case 5:
				continueProgram = false;
				break;
			default:
				break;
			}
		}

	}
	
}
