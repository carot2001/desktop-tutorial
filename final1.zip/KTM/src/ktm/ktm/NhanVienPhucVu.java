package ktm.ktm;

public class NhanVienPhucVu extends NhanVien{
	public NhanVienPhucVu(String maNV, String tenNV, String trinhDo, double luongCoBan) {
		super(maNV, tenNV, trinhDo, luongCoBan);	
	}
	
	//Luong = luongCoBan
	public double tinhLuong() {
		return getLuongCoBan();
	}
}
