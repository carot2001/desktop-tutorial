package ktm.ktm;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HocVien {
	private List<NhanVien>nhanVienList;
	//Hàm tạo mảng cho biến nhanvienlist.
	public HocVien() {
		nhanVienList = new ArrayList<>();
	}
	//Hàm thêm nhân viên.
	public void addElement(NhanVien nhanVien) {
		nhanVienList.add(nhanVien);
	}
	//Hàm show danh sách nhân viên.
	public void showElement() {
		for(NhanVien nhanVien : nhanVienList) {
			System.out.println("Mã nhân viên: " + nhanVien.getMaNV());
			System.out.println("Họ và tên: " + nhanVien.getTenNV());
			System.out.println("Trình độ: " + nhanVien.getTrinhDo());
			System.out.println("Lương cơ bản: " + nhanVien.getLuongCoBan());
			
			if(nhanVien instanceof NhanVienQuanLy) {
				NhanVienQuanLy nhanVienQuanLy = (NhanVienQuanLy) nhanVien;
				System.out.println("Chuyên môn: " + nhanVienQuanLy.getChuyenMon());
				System.out.println("Phụ cấp chức vụ: " + nhanVienQuanLy.getPhuCapChucVu());
			}
			else if(nhanVien instanceof NhanVienNghienCuu) {
				NhanVienNghienCuu nhanVienNghienCuu = (NhanVienNghienCuu) nhanVien;
				System.out.println("Chuyên môn: " + nhanVienNghienCuu.getChuyenMon());
				System.out.println("Phụ cấp độc hại: " + nhanVienNghienCuu.getPhuCapDocHai());
			}
			else if(nhanVien instanceof NhanVienPhucVu) {
				
			}
		}
	}
	
	//Hàm thêm mới nhân viên từ bán phím.
	public void Function() {
	    Scanner sc = new Scanner(System.in);

	    System.out.print("Vui lòng nhập số lượng nhân viên: ");
	    int n = sc.nextInt();
	    sc.nextLine();
	    for (int i = 0; i < n; i++) {
	        System.out.print("Vui lòng nhâp mã nhân viên " + (i + 1) + ": ");
	        String maNv = sc.nextLine();
	        System.out.print("Vui lòng nhập tên nhân viên " + (i + 1) + ": ");
	        String tenNv = sc.nextLine();
	        System.out.print("Vui lòng nhập trình độ: ");
	        String trinhDo = sc.nextLine();
	        System.out.print("Vui lòng nhập lương cơ bản: ");
	        double luongCoBan = sc.nextDouble();
	        sc.nextLine();

	        System.out.println(
	                "Chọn phân loại nhân viên mà bạn muốn nhập: 1. Nhân viên quản lý / 2.Nhân viên nghiên cứu/ 3.Nhân viên phục vụ");
	        int choose = sc.nextInt();
	        sc.nextLine();
	        if (choose == 1) {
	            System.out.print("Vui lòng nhập trình độ chuyên môn: ");
	            String chuyenMon = sc.nextLine();
	            System.out.print("Vui lòng nhập phụ cấp chức vụ: ");
	            double phuCapChucVu = sc.nextDouble();
	            sc.nextLine();
	            NhanVien nhanVienQuanLy = new NhanVienQuanLy(maNv, tenNv, trinhDo, luongCoBan, chuyenMon,
	                    phuCapChucVu);
	            addElement(nhanVienQuanLy);
	        } else if (choose == 2) {
	            System.out.print("Vui lòng nhâp trình độ chuyên môn: ");
	            String chuyenMon = sc.nextLine();
	            System.out.print("Vui lòng nhập phụ cấp độc hại: ");
	            double phuCapDocHai = sc.nextDouble();
	            sc.nextLine();
	            NhanVien nhanVienNghienCuu = new NhanVienNghienCuu(maNv, tenNv, trinhDo, luongCoBan, chuyenMon,
	                    phuCapDocHai);
	            addElement(nhanVienNghienCuu);
	        } else if (choose == 3) {
	            NhanVien nhanVienPhucVu = new NhanVienPhucVu(maNv, tenNv, trinhDo, luongCoBan);
	            addElement(nhanVienPhucVu);
	        }
	    }

	}
	//Hàm tính lương từng nhân viên.
	public void Calculate() {
		System.out.println("Tính lương cho từng nhân viên");
		for(NhanVien nhanVien : nhanVienList) {
			System.out.println("Nhân viên " + nhanVien.getTenNV() + " có mức lương là: " + nhanVien.tinhLuong());
		}
	}
	//Hàm tính tổng lương.
	public double TotalSalary() {
		double Total = 0;
		for(NhanVien nhanVien : nhanVienList) {
			Total += nhanVien.tinhLuong();
		}
		return Total;
	}
	
}
