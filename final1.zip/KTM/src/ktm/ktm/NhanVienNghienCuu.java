package ktm.ktm;

public class NhanVienNghienCuu extends NhanVien {
	private String chuyenMon;
	private double phuCapDocHai;
	
	
	public NhanVienNghienCuu(String maNv, String tenNv, String trinhDo, double luongCoBan, String chuyenMon, double phuCapDocHai) {
		super(maNv, tenNv, trinhDo, luongCoBan);
		this.chuyenMon = chuyenMon;
		this.phuCapDocHai = phuCapDocHai;
	}
	
	public double tinhLuong() {
		return getLuongCoBan() + getPhuCapDocHai();
	}

	public String getChuyenMon() {
		return chuyenMon;
	}

	public void setChuyenMon(String chuyenMon) {
		this.chuyenMon = chuyenMon;
	}

	public double getPhuCapDocHai() {
		return phuCapDocHai;
	}

	public void setPhuCapDocHai(double phuCapDocHai) {
		this.phuCapDocHai = phuCapDocHai;
	}
}
