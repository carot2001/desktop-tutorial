package OOP.cuoiky;
import java.util.Scanner;

/**
 * @author hieulm
 *
 */
public class Entry {
	public static void main(String[] args) {
		//Doi tuong quanlyCanBo thuoc lop QLCB
		QLCB quanLyCanBo = new QLCB();
		
		//Dung tinh da hinh, them 3 doi tuong vao danh sach can bo bang method add
		CanBo cb1 = new CongNhan("Le Mnh Hieu", 22, "Nam", "Dong Nai", 5);
		CanBo cb2 = new KySu("Huynh Khai Van", 22, "Nam", "Long An", "CNTT");
		CanBo cb3 = new NhanVien("Tu Nguyen Minh Dang", 21, "Nam", "Ca Mau", "Security");
		
		quanLyCanBo.addElement(cb1);
		quanLyCanBo.addElement(cb2);
		quanLyCanBo.addElement(cb3);
		
		//Show ra bang method showElement
		quanLyCanBo.showElement();
//		quanLyCanBo.addElement(new CongNhan("A", 22, "Nam", "DongNai", 5));
		CanBo canBo = new CanBo();
//		CongNhan congNhan = new CongNhan("Nguyen Van A", 20, "Nam", "Binh Phuoc", 11);
//		KySu kySu = new KySu("Nguyen Thi Ky Su", 30, "Nu", "Khanh Hoa", "Hoa hoc huu co");
//		NhanVien nhanVien = new NhanVien("Do Huu Ca", 50, "Nam", "Ninh Thuan", "Van Phong"); 
//		canBo.display();
//		congNhan.display();
//		kySu.display();
//		nhanVien.display();
//		quanLyCanBo.addElement(congNhan);
//		quanLyCanBo.addElement(kySu);
//		quanLyCanBo.showElement();
//		
		
		//Nhap bang console
		Scanner scanner = new Scanner(System.in);
		//Dieu kien cua vong lap dowhile
		int chooseView = 1;
		do {
			
		System.out.println("Nhap ho ten: ");
		String name = scanner.nextLine();
		
		System.out.println("Nhap tuoi: ");
		int age = scanner.nextInt();
		scanner.nextLine();
		
		System.out.println("Nhap gioi tinh: ");
		String sex = scanner.nextLine();
		
		System.out.println("Nhap dia chi: ");
		String address = scanner.nextLine();
		
		//Tao 1 bien chooseCB de get loai CB
		System.out.println("Nhap loai can bo: /n 1. Cong nhan 2. Ky su 3. Nhan vien");
		int chooseCB = scanner.nextInt();
		scanner.nextLine();
		
		
		if(chooseCB == 1) {
			System.out.println("Vui long nhap bac cong nhan: ");
			int grade = scanner.nextInt();
			scanner.nextLine();
			canBo = new CongNhan(name, age, sex, address, grade);
		}
		else if(chooseCB == 2) {
			System.out.println("Vui long nhap nganh dao tao: ");
			String major = scanner.nextLine();
			canBo = new KySu(name, age, sex, address, major);
		}
		else if(chooseCB == 3) {
			System.out.println("Vui long nhap cong viec: ");
			String job = scanner.nextLine();
			canBo = new NhanVien(name, age, sex, address, job);
			
		}
		quanLyCanBo.addElement(canBo);
		
		System.out.println("Ban co muon xem danh sach can bo khong?(1 - co/ 0 - khong)");
		int view = scanner.nextInt();
		if(view==1) {
			quanLyCanBo.showElement();
		}
		chooseView = scanner.nextInt();
		} while(chooseView == 1);
	}
}
