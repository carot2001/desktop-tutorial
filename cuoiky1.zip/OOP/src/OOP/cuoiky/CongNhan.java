package OOP.cuoiky;


/**
 * @author hieulm
 *
 */
public class CongNhan extends CanBo {
	private int grade;
	
	public CongNhan(String name, int age, String sex, String address, int grade) {
		super(name, age, sex, address);
		this.grade = grade;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

 
}
